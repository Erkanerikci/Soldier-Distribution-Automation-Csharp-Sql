﻿namespace AskerOtomasyon
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBox1 = new ListBox();
            listBox2 = new ListBox();
            listBox3 = new ListBox();
            listBox4 = new ListBox();
            listBox5 = new ListBox();
            listBox6 = new ListBox();
            listBox7 = new ListBox();
            listBox8 = new ListBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            btndagit = new Button();
            SuspendLayout();
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(760, 407);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(144, 169);
            listBox1.TabIndex = 0;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 15;
            listBox2.Location = new Point(21, 34);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(126, 289);
            listBox2.TabIndex = 0;
            // 
            // listBox3
            // 
            listBox3.FormattingEnabled = true;
            listBox3.ItemHeight = 15;
            listBox3.Location = new Point(153, 34);
            listBox3.Name = "listBox3";
            listBox3.Size = new Size(126, 289);
            listBox3.TabIndex = 0;
            // 
            // listBox4
            // 
            listBox4.FormattingEnabled = true;
            listBox4.ItemHeight = 15;
            listBox4.Location = new Point(285, 34);
            listBox4.Name = "listBox4";
            listBox4.Size = new Size(126, 289);
            listBox4.TabIndex = 0;
            // 
            // listBox5
            // 
            listBox5.FormattingEnabled = true;
            listBox5.ItemHeight = 15;
            listBox5.Location = new Point(417, 34);
            listBox5.Name = "listBox5";
            listBox5.Size = new Size(126, 289);
            listBox5.TabIndex = 0;
            // 
            // listBox6
            // 
            listBox6.FormattingEnabled = true;
            listBox6.ItemHeight = 15;
            listBox6.Location = new Point(549, 34);
            listBox6.Name = "listBox6";
            listBox6.Size = new Size(126, 289);
            listBox6.TabIndex = 0;
            // 
            // listBox7
            // 
            listBox7.FormattingEnabled = true;
            listBox7.ItemHeight = 15;
            listBox7.Location = new Point(681, 34);
            listBox7.Name = "listBox7";
            listBox7.Size = new Size(126, 289);
            listBox7.TabIndex = 0;
            // 
            // listBox8
            // 
            listBox8.FormattingEnabled = true;
            listBox8.ItemHeight = 15;
            listBox8.Location = new Point(813, 34);
            listBox8.Name = "listBox8";
            listBox8.Size = new Size(126, 289);
            listBox8.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(56, 9);
            label1.Name = "label1";
            label1.Size = new Size(53, 15);
            label1.TabIndex = 1;
            label1.Text = "Pazartesi";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(192, 9);
            label2.Name = "label2";
            label2.Size = new Size(25, 15);
            label2.TabIndex = 1;
            label2.Text = "Salı";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(315, 9);
            label3.Name = "label3";
            label3.Size = new Size(60, 15);
            label3.TabIndex = 1;
            label3.Text = "Çarşamba";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(445, 9);
            label4.Name = "label4";
            label4.Size = new Size(59, 15);
            label4.TabIndex = 1;
            label4.Text = "Perşembe";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(587, 9);
            label5.Name = "label5";
            label5.Size = new Size(39, 15);
            label5.TabIndex = 1;
            label5.Text = "Cuma";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(707, 9);
            label6.Name = "label6";
            label6.Size = new Size(61, 15);
            label6.TabIndex = 1;
            label6.Text = "Cumartesi";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(838, 9);
            label7.Name = "label7";
            label7.Size = new Size(35, 15);
            label7.TabIndex = 1;
            label7.Text = "Pazar";
            // 
            // btndagit
            // 
            btndagit.Location = new Point(390, 340);
            btndagit.Name = "btndagit";
            btndagit.Size = new Size(129, 80);
            btndagit.TabIndex = 2;
            btndagit.Text = "Dağıt";
            btndagit.UseVisualStyleBackColor = true;
            btndagit.Click += btndagit_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1043, 654);
            Controls.Add(btndagit);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(listBox8);
            Controls.Add(listBox7);
            Controls.Add(listBox6);
            Controls.Add(listBox5);
            Controls.Add(listBox4);
            Controls.Add(listBox3);
            Controls.Add(listBox2);
            Controls.Add(listBox1);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load_1;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBox1;
        private ListBox listBox2;
        private ListBox listBox3;
        private ListBox listBox4;
        private ListBox listBox5;
        private ListBox listBox6;
        private ListBox listBox7;
        private ListBox listBox8;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Button btndagit;
    }
}